# GPL-3.0 license
import bpy
import re
from . import shared_functions

class FilterSelection(bpy.types.Operator):
    '''
    Filter all the selected objects by:
        - Object Name
        - Object Type
    '''
    bl_idname = 'object.filter_selection'
    bl_label = 'Filter Selection '
    bl_options = {"REGISTER", "UNDO"}
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects

    # update function, which makes sure min is never
    # lager than max and max is never smaller than min
    def update_BB_min_func(self, context):
        if self.prop_BB_max < self.prop_BB_min:
            self.prop_BB_max = self.prop_BB_min

    def update_BB_max_func(self, context):
        if self.prop_BB_min > self.prop_BB_max:
            self.prop_BB_min = self.prop_BB_max

    # Revert to annotation style so Blender registers these as RNA properties
    prop_use_regex: bpy.props.BoolProperty(
        name='Use Regex',
        default=False
        )
    prop_namefilter: bpy.props.StringProperty(
        name='Name Filter',
        default='*',
        options={'TEXTEDIT_UPDATE'}
        )

    prop_BB_min: bpy.props.FloatProperty(
        name='Min Size (%)',
        update=update_BB_min_func,
        default=0,
        soft_min=0,
        soft_max=100
        )
    prop_BB_max: bpy.props.FloatProperty(
        name='Max Size (%)',
        update=update_BB_max_func,
        default=100,
        soft_min=0,
        soft_max=100
        )

    prop_types: bpy.props.EnumProperty(
        name='Include Types:',
        description="My enum description",
        items=[
            ('MESH', "Mesh", "Active Button"),
            ('CURVE', "Curve", "Show a Slider"),
            ('SURFACE', "Surface", "Show a Slider"),
            ('META', "Metaball", "Show a Slider"),
            ('FONT', "Text", "Show a Slider"),
            ('VOLUME', "Volue", "Show a Slider"),
            ('EMPTY', "Empty", "Show a Slider")
            ],
            options = {"ENUM_FLAG"}
    )

    def invoke(self, context, event):
        # set default object types:
        self.prop_types = {
            'MESH',
            'CURVE',
            'SURFACE',
            'META',
            'FONT',
            'VOLUME'
            }
        self.prop_BB_min = 0
        self.prop_BB_max = 100
        self.prop_namefilter = '*'
        self.prop_use_regex = False

        return self.execute(context)

    def execute(self, context):
        init_selection = list(context.selected_objects)  # snapshot selection

        # deselect everything in this view layer (avoid bpy.ops)
        for o in context.view_layer.objects:
            o.select_set(False)

        # prepair name filtering regex:
        if self.prop_use_regex:
            try:
                pattern = re.compile(self.prop_namefilter)
            except:
                shared_functions.report_warning(self, 'Regex failed, no matches returned.')
                pattern = re.compile('a^')
        else:
            p_string = self.prop_namefilter
            # match any character 1 or more times
            p_string = p_string.replace('*', '.*')
            # match any character 1 or more times
            p_string = p_string.replace('%', '.*')
            # match single character
            p_string = p_string.replace('?', '.{1}')
            p_string = '(?i)' + p_string
            pattern = re.compile(p_string)

        # do the filtering of the selection here...
        if not init_selection:
            shared_functions.report_info(self, 'No selection')
            return {'CANCELLED'}

        self.biggest_BB_size = max([obj.dimensions.length for obj in init_selection])

        selected_count = 0
        for obj in init_selection:
            match_bb = (self.prop_BB_min <= obj.dimensions.length / self.biggest_BB_size * 100 <= self.prop_BB_max)
            match_type = (obj.type in self.prop_types)
            match_name = bool(re.match(pattern, obj.name))
            if match_bb and match_type and match_name:
                obj.select_set(True)
                selected_count += 1

        shared_functions.report_info(self, f'{selected_count} of {len(init_selection)} currently selected')
        return {'FINISHED'}

    def draw(self, context):

        layout = self.layout
        layout.use_property_split = True

        box = layout.box()
        box.label(text='Filter by Object Name', icon='GREASEPENCIL')
        box.prop(self, 'prop_use_regex')
        box.prop(self, 'prop_namefilter')

        layout.separator(factor=1)

        box = layout.box()
        box.label(text='Filter by Object Type', icon='OBJECT_DATA')
        box.prop(self, "prop_types", toggle=True)

        layout.separator(factor=1)



##############################################################################
# Add-On Handling
##############################################################################
classes = (
    FilterSelection,
)

def register():
    # register classes
    for c in classes:
        bpy.utils.register_class(c)
        print(f'registered {c}')


def unregister():
    # unregister classes
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
        print(f'unregistered {c}')
